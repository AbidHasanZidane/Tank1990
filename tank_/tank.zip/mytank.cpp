#include "mytank.h"

MyTank::MyTank()
{
    this->setPixmap(QPixmap("://F:/90_tank/player_tank/Icon-hdpi.png"));

    this->setPos(200,200);
}
